var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/auth.ts
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";

// db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  achievements: () => achievements,
  challenges: () => challenges,
  challengesRelations: () => challengesRelations,
  insertUserSchema: () => insertUserSchema,
  insertWearableActivitySchema: () => insertWearableActivitySchema,
  insertWearableDeviceSchema: () => insertWearableDeviceSchema,
  participations: () => participations,
  selectUserSchema: () => selectUserSchema,
  transactions: () => transactions,
  users: () => users,
  usersRelations: () => usersRelations,
  wearableActivities: () => wearableActivities,
  wearableActivitiesRelations: () => wearableActivitiesRelations,
  wearableDevices: () => wearableDevices,
  wearableDevicesRelations: () => wearableDevicesRelations
});
import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
var users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique().notNull(),
  password: text("password").notNull(),
  points: integer("points").default(0).notNull(),
  level: integer("level").default(1).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  creatorId: integer("creator_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  targetReps: integer("target_reps").notNull(),
  betAmount: decimal("bet_amount").notNull(),
  status: text("status").default("active").notNull(),
  endDate: timestamp("end_date").notNull(),
  visibility: text("visibility").default("public").notNull(),
  teamSize: integer("team_size").default(1).notNull(),
  verificationMethod: text("verification_method").default("camera").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var participations = pgTable("participations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  challengeId: integer("challenge_id").references(() => challenges.id).notNull(),
  currentReps: integer("current_reps").default(0).notNull(),
  completed: boolean("completed").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull()
});
var transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  challengeId: integer("challenge_id").references(() => challenges.id).notNull(),
  amount: decimal("amount").notNull(),
  type: text("type").notNull(),
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var wearableDevices = pgTable("wearable_devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  deviceType: text("device_type").notNull(),
  deviceId: text("device_id").notNull(),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  tokenExpiresAt: timestamp("token_expires_at"),
  lastSyncedAt: timestamp("last_synced_at"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var wearableActivities = pgTable("wearable_activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  deviceId: integer("device_id").references(() => wearableDevices.id).notNull(),
  activityType: text("activity_type").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  duration: integer("duration").notNull(),
  calories: integer("calories"),
  steps: integer("steps"),
  distance: decimal("distance"),
  heartRate: jsonb("heart_rate"),
  rawData: jsonb("raw_data"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var usersRelations = relations(users, ({ many }) => ({
  challenges: many(challenges),
  participations: many(participations),
  achievements: many(achievements),
  transactions: many(transactions),
  wearableDevices: many(wearableDevices),
  wearableActivities: many(wearableActivities)
}));
var challengesRelations = relations(challenges, ({ one, many }) => ({
  creator: one(users, {
    fields: [challenges.creatorId],
    references: [users.id]
  }),
  participations: many(participations),
  transactions: many(transactions)
}));
var wearableDevicesRelations = relations(wearableDevices, ({ one, many }) => ({
  user: one(users, {
    fields: [wearableDevices.userId],
    references: [users.id]
  }),
  activities: many(wearableActivities)
}));
var wearableActivitiesRelations = relations(wearableActivities, ({ one }) => ({
  user: one(users, {
    fields: [wearableActivities.userId],
    references: [users.id]
  }),
  device: one(wearableDevices, {
    fields: [wearableActivities.deviceId],
    references: [wearableDevices.id]
  })
}));
var insertUserSchema = createInsertSchema(users);
var selectUserSchema = createSelectSchema(users);
var insertWearableDeviceSchema = createInsertSchema(wearableDevices);
var insertWearableActivitySchema = createInsertSchema(wearableActivities);

// db/index.ts
import pkg from "pg";
import { drizzle } from "drizzle-orm/neon-serverless";
var { Pool } = pkg;
var DATABASE_URL = "postgres://postgres:Commit1212@database-1.cr0oqaqes3iv.us-east-1.rds.amazonaws.com:5432/postgres";
if (!DATABASE_URL) {
  throw new Error("DATABASE_URL must be set. Did you forget to provision a database?");
}
var pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
    // Required for cloud-hosted databases
  }
});
var db = drizzle(pool, { schema: schema_exports });
(async () => {
  try {
    const result = await db.select().from(users);
    console.log("Connected to the database successfully:", result);
  } catch (error) {
    console.error("Database connection failed:", error);
  }
})();

// server/auth.ts
import { eq } from "drizzle-orm";
var scryptAsync = promisify(scrypt);
var crypto = {
  hash: async (password) => {
    const salt = randomBytes(16).toString("hex");
    const buf = await scryptAsync(password, salt, 64);
    return `${buf.toString("hex")}.${salt}`;
  },
  compare: async (suppliedPassword, storedPassword) => {
    const [hashedPassword, salt] = storedPassword.split(".");
    const hashedPasswordBuf = Buffer.from(hashedPassword, "hex");
    const suppliedPasswordBuf = await scryptAsync(
      suppliedPassword,
      salt,
      64
    );
    return timingSafeEqual(hashedPasswordBuf, suppliedPasswordBuf);
  }
};
function setupAuth(app2) {
  const MemoryStore = createMemoryStore(session);
  const sessionSettings = {
    secret: process.env.REPL_ID || "secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {},
    store: new MemoryStore({
      checkPeriod: 864e5
    })
  };
  if (app2.get("env") === "production") {
    app2.set("trust proxy", 1);
    sessionSettings.cookie = {
      secure: true
    };
  }
  app2.use(session(sessionSettings));
  app2.use(passport.initialize());
  app2.use(passport.session());
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
        if (!user) {
          return done(null, false, { message: "Incorrect username." });
        }
        const isMatch = await crypto.compare(password, user.password);
        if (!isMatch) {
          return done(null, false, { message: "Incorrect password." });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });
  passport.deserializeUser(async (id, done) => {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });
  app2.post("/api/register", async (req, res, next) => {
    try {
      const result = insertUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).send(
          "Invalid input: " + result.error.issues.map((i) => i.message).join(", ")
        );
      }
      const { username, password } = result.data;
      const [existingUser] = await db.select().from(users).where(eq(users.username, username)).limit(1);
      if (existingUser) {
        return res.status(400).send("Username already exists");
      }
      const hashedPassword = await crypto.hash(password);
      const [newUser] = await db.insert(users).values({
        username,
        password: hashedPassword
      }).returning();
      req.login(newUser, (err) => {
        if (err) {
          return next(err);
        }
        return res.json({
          message: "Registration successful",
          user: { id: newUser.id, username: newUser.username }
        });
      });
    } catch (error) {
      next(error);
    }
  });
  app2.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(400).send(info.message ?? "Login failed");
      }
      req.logIn(user, (err2) => {
        if (err2) {
          return next(err2);
        }
        return res.json({
          message: "Login successful",
          user: { id: user.id, username: user.username }
        });
      });
    })(req, res, next);
  });
  app2.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).send("Logout failed");
      }
      res.json({ message: "Logout successful" });
    });
  });
  app2.get("/api/user", (req, res) => {
    if (req.isAuthenticated()) {
      return res.json(req.user);
    }
    res.status(401).send("Not logged in");
  });
}

// server/websocket.ts
import { WebSocketServer, WebSocket } from "ws";
function setupWebSocket(server) {
  const wss = new WebSocketServer({
    server,
    path: "/ws",
    verifyClient: (info, cb) => {
      if (info.req.headers["sec-websocket-protocol"] === "vite-hmr") {
        return cb(false);
      }
      cb(true);
    }
  });
  const clients = /* @__PURE__ */ new Map();
  wss.on("connection", (ws) => {
    const clientId = Math.random().toString(36).substring(2);
    clients.set(clientId, { id: clientId, ws });
    ws.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString());
        switch (data.type) {
          case "challenge_update":
            broadcastToAll({
              type: "challenge_update",
              payload: data.payload
            });
            break;
          case "leaderboard_update":
            broadcastToAll({
              type: "leaderboard_update",
              payload: data.payload
            });
            break;
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    });
    ws.on("close", () => {
      clients.delete(clientId);
    });
    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
      clients.delete(clientId);
    });
  });
  function broadcastToAll(data) {
    const message = JSON.stringify(data);
    clients.forEach((client) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        try {
          client.ws.send(message);
        } catch (error) {
          console.error("Error broadcasting to client:", error);
        }
      }
    });
  }
  return {
    broadcastToAll
  };
}

// server/wearable.ts
import { eq as eq2 } from "drizzle-orm";
var isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).send("Not authenticated");
};
function setupWearableRoutes(app2) {
  app2.get("/api/wearables", isAuthenticated, async (req, res) => {
    try {
      const devices = await db.select().from(wearableDevices).where(eq2(wearableDevices.userId, req.user.id));
      res.json(devices);
    } catch (error) {
      res.status(500).send("Failed to fetch wearable devices");
    }
  });
  app2.post("/api/wearables/connect", isAuthenticated, async (req, res) => {
    try {
      const result = insertWearableDeviceSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).send(result.error.message);
      }
      const [device] = await db.insert(wearableDevices).values({
        ...result.data,
        userId: req.user.id
      }).returning();
      res.json(device);
    } catch (error) {
      res.status(500).send("Failed to connect wearable device");
    }
  });
  app2.post("/api/wearables/:deviceId/sync", isAuthenticated, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.deviceId);
      const [device] = await db.select().from(wearableDevices).where(eq2(wearableDevices.id, deviceId)).limit(1);
      if (!device || device.userId !== req.user.id) {
        return res.status(404).send("Device not found");
      }
      await db.update(wearableDevices).set({ lastSyncedAt: /* @__PURE__ */ new Date() }).where(eq2(wearableDevices.id, deviceId));
      res.json({ message: "Sync completed successfully" });
    } catch (error) {
      res.status(500).send("Failed to sync device data");
    }
  });
  app2.get("/api/wearables/:deviceId/activities", isAuthenticated, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.deviceId);
      const [device] = await db.select().from(wearableDevices).where(eq2(wearableDevices.id, deviceId)).limit(1);
      if (!device || device.userId !== req.user.id) {
        return res.status(404).send("Device not found");
      }
      const activities = await db.select().from(wearableActivities).where(eq2(wearableActivities.deviceId, deviceId)).orderBy(wearableActivities.startTime);
      res.json(activities);
    } catch (error) {
      res.status(500).send("Failed to fetch device activities");
    }
  });
}

// server/routes.ts
import { eq as eq3, desc, and, sql } from "drizzle-orm";
import { z } from "zod";
var isAuthenticated2 = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).send("Not authenticated");
};
function registerRoutes(app2) {
  setupAuth(app2);
  setupWearableRoutes(app2);
  const httpServer = createServer(app2);
  const ws = setupWebSocket(httpServer);
  app2.get("/api/challenges", isAuthenticated2, async (req, res) => {
    try {
      const allChallenges = await db.select().from(challenges).orderBy(desc(challenges.createdAt));
      res.json(allChallenges);
    } catch (error) {
      res.status(500).send("Failed to fetch challenges");
    }
  });
  app2.get("/api/challenges/:id", isAuthenticated2, async (req, res) => {
    try {
      const [challenge] = await db.select().from(challenges).where(eq3(challenges.id, parseInt(req.params.id))).limit(1);
      if (!challenge) {
        return res.status(404).send("Challenge not found");
      }
      res.json(challenge);
    } catch (error) {
      res.status(500).send("Failed to fetch challenge");
    }
  });
  const createChallengeSchema = z.object({
    title: z.string().min(1),
    description: z.string().min(1),
    type: z.enum(["pushup", "squat", "situp"]),
    targetReps: z.number().min(1),
    betAmount: z.number().min(1),
    endDate: z.string().transform((str) => new Date(str))
  });
  app2.post("/api/challenges", isAuthenticated2, async (req, res) => {
    try {
      const result = createChallengeSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).send(result.error.message);
      }
      const [challenge] = await db.insert(challenges).values({
        title: result.data.title,
        description: result.data.description,
        type: result.data.type,
        targetReps: result.data.targetReps,
        betAmount: result.data.betAmount.toString(),
        endDate: result.data.endDate,
        creatorId: req.user.id,
        status: "active"
      }).returning();
      ws.broadcastToAll({
        type: "challenge_update",
        payload: { action: "created", challenge }
      });
      res.json(challenge);
    } catch (error) {
      res.status(500).send("Failed to create challenge");
    }
  });
  app2.post("/api/challenges/:id/join", isAuthenticated2, async (req, res) => {
    try {
      const challengeId = parseInt(req.params.id);
      const userId = req.user.id;
      const [existing] = await db.select().from(participations).where(
        and(
          eq3(participations.challengeId, challengeId),
          eq3(participations.userId, userId)
        )
      ).limit(1);
      if (existing) {
        return res.status(400).send("Already participating in this challenge");
      }
      const [challenge] = await db.select().from(challenges).where(eq3(challenges.id, challengeId)).limit(1);
      if (!challenge) {
        return res.status(404).send("Challenge not found");
      }
      await db.transaction(async (tx) => {
        await tx.insert(participations).values({
          userId,
          challengeId,
          currentReps: 0,
          completed: false
        });
        await tx.insert(transactions).values({
          userId,
          challengeId,
          amount: challenge.betAmount,
          type: "bet",
          status: "pending"
        });
      });
      res.json({ message: "Successfully joined challenge" });
    } catch (error) {
      res.status(500).send("Failed to join challenge");
    }
  });
  app2.post("/api/challenges/:id/progress", isAuthenticated2, async (req, res) => {
    try {
      const challengeId = parseInt(req.params.id);
      const userId = req.user.id;
      const reps = parseInt(req.body.reps);
      if (isNaN(reps) || reps < 0) {
        return res.status(400).send("Invalid rep count");
      }
      const [participation] = await db.select().from(participations).where(
        and(
          eq3(participations.challengeId, challengeId),
          eq3(participations.userId, userId)
        )
      ).limit(1);
      if (!participation) {
        return res.status(404).send("Not participating in this challenge");
      }
      const updatedReps = participation.currentReps + reps;
      const [challenge] = await db.select().from(challenges).where(eq3(challenges.id, challengeId)).limit(1);
      const completed = updatedReps >= challenge.targetReps;
      await db.update(participations).set({
        currentReps: updatedReps,
        completed
      }).where(eq3(participations.id, participation.id));
      await db.update(users).set({
        points: req.user.points + reps
      }).where(eq3(users.id, userId));
      if (completed) {
        await db.insert(achievements).values({
          userId,
          type: "challenge_complete",
          title: "Challenge Champion",
          description: `Completed ${challenge.title}`
        });
        await db.insert(transactions).values({
          userId,
          challengeId,
          amount: (parseFloat(challenge.betAmount) * 2).toString(),
          type: "reward",
          status: "completed"
        });
      }
      ws.broadcastToAll({
        type: "challenge_update",
        payload: {
          action: "progress",
          challengeId,
          userId,
          updatedReps,
          completed
        }
      });
      res.json({ message: "Progress updated successfully" });
    } catch (error) {
      res.status(500).send("Failed to update progress");
    }
  });
  app2.get("/api/leaderboard", isAuthenticated2, async (req, res) => {
    try {
      const leaderboard = await db.select({
        id: users.id,
        username: users.username,
        points: users.points,
        level: users.level
      }).from(users).orderBy(desc(users.points)).limit(10);
      const enhancedLeaderboard = await Promise.all(
        leaderboard.map(async (user) => {
          const userAchievements = await db.select().from(achievements).where(eq3(achievements.userId, user.id)).orderBy(desc(achievements.unlockedAt)).limit(3);
          const [{ completedCount }] = await db.select({
            completedCount: sql`count(*)::int`
          }).from(participations).where(
            and(
              eq3(participations.userId, user.id),
              eq3(participations.completed, true)
            )
          );
          const [{ totalChallenges }] = await db.select({
            totalChallenges: sql`count(*)::int`
          }).from(participations).where(eq3(participations.userId, user.id));
          const winRate = totalChallenges > 0 ? Math.round(completedCount / totalChallenges * 100) : 0;
          return {
            ...user,
            achievements: userAchievements,
            completedChallenges: completedCount,
            winRate
          };
        })
      );
      res.json(enhancedLeaderboard);
    } catch (error) {
      console.error("Failed to fetch leaderboard:", error);
      res.status(500).send("Failed to fetch leaderboard");
    }
  });
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2, { dirname as dirname2 } from "path";
import { fileURLToPath as fileURLToPath2 } from "url";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import themePlugin from "@replit/vite-plugin-shadcn-theme-json";
import path, { dirname } from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = dirname(__filename);
var vite_config_default = defineConfig({
  plugins: [react(), runtimeErrorOverlay(), themePlugin()],
  resolve: {
    alias: {
      "@db": path.resolve(__dirname, "db"),
      "@": path.resolve(__dirname, "client", "src")
    }
  },
  root: path.resolve(__dirname, "client"),
  // Ensure client folder is the root
  build: {
    outDir: path.resolve(__dirname, "dist/public"),
    // Ensure correct frontend build directory
    emptyOutDir: true
    // Clears previous builds
  },
  server: {
    port: 3e3,
    // Optional: Set a default local development port
    strictPort: true,
    open: true
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var __filename2 = fileURLToPath2(import.meta.url);
var __dirname2 = dirname2(__filename2);
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: {
      middlewareMode: true,
      hmr: { server }
    },
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        __dirname2,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(`src="/src/main.tsx"`, `src="/src/main.tsx?v=${nanoid()}"`);
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(__dirname2, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.get("/health", (_req, res) => {
  res.json({ status: "OK" });
});
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
app.use((err, _req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(status).json({ message });
  throw err;
});
if (app.get("env") === "development") {
  await setupVite(app);
}
registerRoutes(app);
var PORT = process.env.PORT || 8080;
app.listen(PORT, "0.0.0.0", () => {
  log(`Server is running on port ${PORT}`);
});
serveStatic(app);
